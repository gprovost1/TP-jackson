import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JavaToJson {
	public static String javaToJson(Person personne) throws JsonProcessingException {
		ObjectMapper om = new ObjectMapper();
		String result = null;
		result = om.writeValueAsString(personne);
		return result;
	}
}
