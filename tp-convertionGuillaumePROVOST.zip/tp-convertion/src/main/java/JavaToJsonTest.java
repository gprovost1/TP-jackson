import static org.junit.Assert.*;

import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;

public class JavaToJsonTest {

	@Test
	public void testJavaToJson() throws JsonProcessingException {
		String json = "{\"nom\":\"Provost\",\"prenom\":\"Guillaume\",\"adresse\":{\"numero\":\"140\",\"typeVoie\":\"rue\",\"nomVoie\":\"Nouvelle France\",\"zipCode\":\"93100\",\"ville\":\"Montreuil\"}}";
		Adress a = new Adress("140","rue","Nouvelle France","93100","Montreuil");
		Person p = new Person("Provost","Guillaume", a);
		assertEquals(json,JavaToJson.javaToJson(p));
	}
}

