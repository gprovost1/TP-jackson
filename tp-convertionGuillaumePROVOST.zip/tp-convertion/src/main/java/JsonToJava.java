import java.io.IOException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonToJava {
	public static Person jsonToJava(String personne) throws JsonParseException, JsonMappingException, IOException  {
		ObjectMapper om = new ObjectMapper();
		Person result = null;
		result = om.readValue(personne, Person.class);
		return result;
	}
}
