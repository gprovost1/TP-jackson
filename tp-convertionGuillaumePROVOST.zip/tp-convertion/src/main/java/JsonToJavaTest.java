import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;

public class JsonToJavaTest {

	@Test
	public void testJsonToJava() throws IOException {
		String json = "{\"nom\": \"Provost\",\"prenom\": \"Guillaume\",\"adresse\":{\"numero\":\"140\",\"typeVoie\":\"rue\",\"nomVoie\":\"Nouvelle France\",\"zipCode\":\"93100\",\"ville\":\"Montreuil\"}}";
		Adress a = new Adress("140","rue","Nouvelle France","93100","Montreuil");
		Person p = new Person("Provost","Guillaume", a);
		assertEquals(p,JsonToJava.jsonToJava(json));
	}

}
